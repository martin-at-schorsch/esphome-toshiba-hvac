// esphome/components/toshiba_hvac/toshiba_hvac.cpp

#include "toshiba_hvac.h"
#include "esphome/core/log.h"
#include "esphome/core/helpers.h"

namespace esphome {
namespace toshiba_hvac {

const char *const ToshibaHVACClimate::TAG = "toshiba_hvac";

using namespace climate;

const std::vector<uint8_t> SET_MODE_TEMP_COMMAND_PREFIX = {0x20, 0x00, 0x00, 0x00, 0x11, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
const std::vector<uint8_t> FAN_SPEED_COMMAND_PREFIX = {0x20, 0x00, 0x00, 0x00, 0x09, 0x50, 0x00, 0x00, 0x00, 0x00};

void ToshibaHVACClimate::setup() {
    ESP_LOGCONFIG(TAG, "Toshiba HVAC wird eingerichtet...");
    this->mode = CLIMATE_MODE_OFF;
    this->target_temperature = 22.0f;
    this->fan_mode = CLIMATE_FAN_AUTO;
    
    // Initialen Zustand für den Vergleich speichern.
    // KORREKTUR: 'mode' und 'target_temperature' sind keine optional-Typen.
    this->last_sent_mode_ = this->mode;
    this->last_sent_target_temperature_ = this->target_temperature;
    
    // 'fan_mode' ist ein optional, daher muss hier der Wert ausgepackt werden.
    if (this->fan_mode.has_value()) {
        this->last_sent_fan_mode_ = *this->fan_mode;
    }
}

void ToshibaHVACClimate::dump_config() {
    LOG_CLIMATE("", "Toshiba HVAC", this);
}

void ToshibaHVACClimate::loop() {
    // Hier könnte Polling-Logik implementiert werden
}

ClimateTraits ToshibaHVACClimate::traits() {
    auto traits = ClimateTraits();
    traits.set_supports_current_temperature(false);
    traits.set_visual_min_temperature(17.0f);
    traits.set_visual_max_temperature(30.0f);
    traits.set_visual_temperature_step(1.0f);

    traits.set_supported_modes({
        CLIMATE_MODE_OFF, CLIMATE_MODE_COOL, CLIMATE_MODE_HEAT,
        CLIMATE_MODE_DRY, CLIMATE_MODE_FAN_ONLY, CLIMATE_MODE_AUTO
    });

    traits.set_supported_fan_modes({
        CLIMATE_FAN_AUTO, CLIMATE_FAN_LOW, CLIMATE_FAN_MEDIUM, CLIMATE_FAN_HIGH
    });

    return traits;
}

void ToshibaHVACClimate::control(const ClimateCall &call) {
    if (call.get_mode().has_value()) {
        this->mode = *call.get_mode();
    }
    if (call.get_target_temperature().has_value()) {
        this->target_temperature = *call.get_target_temperature();
    }
    if (call.get_fan_mode().has_value()) {
        this->fan_mode = *call.get_fan_mode();
    }

    this->set_hvac_state();
    this->publish_state();
}

void ToshibaHVACClimate::set_hvac_state() {
    // KORREKTUR: Vergleiche 'mode' und 'target_temperature' direkt.
    if (this->mode != this->last_sent_mode_ || this->target_temperature != this->last_sent_target_temperature_) {
        ESP_LOGD(TAG, "Sende Modus/Temperatur: %s, %.1f°C", climate_mode_to_string(this->mode), this->target_temperature);

        auto op_mode = this->esphome_mode_to_toshiba(this->mode);
        auto temp = static_cast<uint8_t>(this->target_temperature);

        std::vector<uint8_t> command = SET_MODE_TEMP_COMMAND_PREFIX;
        // command[7] = (uint8_t)op_mode; // TODO: An dein Protokoll anpassen
        // command[8] = temp;
        this->send_hvac_command(command);

        this->last_sent_mode_ = this->mode;
        this->last_sent_target_temperature_ = this->target_temperature;
    }

    // KORREKTUR: 'fan_mode' ist optional, daher hier die Prüfung und das Auspacken.
    if (this->fan_mode.has_value() && *this->fan_mode != this->last_sent_fan_mode_) {
        ESP_LOGD(TAG, "Sende Lüftermodus: %s", climate_fan_mode_to_string(*this->fan_mode));

        auto fan_speed = this->esphome_fan_mode_to_toshiba(*this->fan_mode);
        std::vector<uint8_t> command = FAN_SPEED_COMMAND_PREFIX;
        // command[7] = (uint8_t)fan_speed; // TODO: An dein Protokoll anpassen
        this->send_hvac_command(command);

        this->last_sent_fan_mode_ = *this->fan_mode;
    }
}

void ToshibaHVACClimate::send_hvac_command(const std::vector<uint8_t> &command) {
    if (this->uart_ == nullptr) {
        ESP_LOGE(TAG, "UART nicht konfiguriert!");
        return;
    }
    ESP_LOGD(TAG, "Sende Befehl: %s", format_hex_pretty(command).c_str());
    this->uart_->write_array(command);
}

OperationMode ToshibaHVACClimate::esphome_mode_to_toshiba(ClimateMode mode) {
    switch (mode) {
        case CLIMATE_MODE_COOL:     return OperationMode::COOL;
        case CLIMATE_MODE_HEAT:     return OperationMode::HEAT;
        case CLIMATE_MODE_DRY:      return OperationMode::DRY;
        case CLIMATE_MODE_FAN_ONLY: return OperationMode::FAN_ONLY;
        case CLIMATE_MODE_AUTO:     return OperationMode::AUTO;
        default:                    return OperationMode::OFF;
    }
}

FanSpeed ToshibaHVACClimate::esphome_fan_mode_to_toshiba(ClimateFanMode fan_mode) {
    switch (fan_mode) {
        case CLIMATE_FAN_LOW:    return FanSpeed::FAN_LOW;
        case CLIMATE_FAN_MEDIUM: return FanSpeed::MEDIUM;
        case CLIMATE_FAN_HIGH:   return FanSpeed::FAN_HIGH;
        default:                 return FanSpeed::AUTO;
    }
}

}  // namespace toshiba_hvac
}  // namespace esphome
